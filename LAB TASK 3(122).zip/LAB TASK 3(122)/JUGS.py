# Water Jug Puzzle solved with Depth First Search
# Jugs: 4L and 3L → Target: 2 Liters

CAP_A = 4      # capacity of jug A
CAP_B = 3      # capacity of jug B
TARGET = 2     # required amount of water

checked = set()   # store visited states


def show_step(rule, position):
    """Display the action taken and the new state."""
    print("Action:", rule, "-> State:", position)


def search(state):
    a, b = state

    # check if goal is achieved
    if a == TARGET or b == TARGET:
        print("\nGoal achieved!")
        print("Resulting state:", state)
        return True

    checked.add(state)

    # possible operations
    moves = [
        (CAP_A, b, "Fill jug A"),
        (a, CAP_B, "Fill jug B"),
        (0, b, "Empty jug A"),
        (a, 0, "Empty jug B"),

        # pour A into B
        (a - min(a, CAP_B - b), b + min(a, CAP_B - b), "Pour A → B"),

        # pour B into A
        (a + min(b, CAP_A - a), b - min(b, CAP_A - a), "Pour B → A")
    ]

    for na, nb, step in moves:
        next_state = (na, nb)

        if next_state not in checked:
            show_step(step, next_state)

            if search(next_state):
                return True

    return False


# starting point
start_state = (0, 0)

print("Water Jug Problem using DFS")
print("Starting state:", start_state)

search(start_state)